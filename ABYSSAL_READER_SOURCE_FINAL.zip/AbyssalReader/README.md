# ABYSSAL READER — The Forbidden Library

Versión inicial Android 0.1.0. Lector PDF y traductor inglés → español. Google Translate mediante ML Kit ejecuta la traducción en el dispositivo. Sin cuentas, anuncios, clave API ni suscripción. Consulta INFORME_TECNICO.md para diferenciar implementación, compilación y ejecución verificadas.

## Instalar y utilizar

Android 8.0 (API 26) o posterior. Abre el APK de prueba en tu teléfono y permite instalar desde la aplicación que lo abre cuando Android lo solicite. Esta es una versión debug, no una publicación de Google Play.

Entra a la biblioteca e importa un PDF mediante el selector Android. En Ajustes descarga el modelo español usando Wi-Fi. Espera el mensaje de disponibilidad. Luego abre un PDF, desliza verticalmente, pellizca para ampliar y usa Restablecer para volver a navegar entre páginas. Ir acepta números desde 1. Puedes marcar páginas y recuperar tu última posición.

Texto / Traducir extrae la página visible al Oráculo. Mantén pulsado el campo de texto, ajusta la selección y pulsa Traducir selección con Google, o traduce todo el campo mediante Traducir página con Google. La selección se realiza en la vista de texto extraído: NO está superpuesta sobre las coordenadas del PDF. El resultado muestra original y traducción juntos, permite copiar y guardar en Archivo de Conocimientos. Allí puedes buscar, eliminar y alternar vocabulario e historial. Se muestra todo el vocabulario guardado y las 500 entradas más recientes.

Los PDF escaneados sin texto se pueden leer pero NO traducir directamente: OCR pendiente. La app informa esa limitación. Los PDF cifrados o con extracción restringida pueden rechazarse. Las columnas y fuentes especiales pueden alterar el orden del texto. La extracción se limita a archivos de 300 MB, sin imponer ese límite al renderizado. No se modifica el PDF original. Si lo borras o mueves, vuelve a importarlo.

## Compilar

Android Studio compatible con AGP 8.9.2, JDK 17, SDK 35, Build Tools 35.0.0 y Gradle 8.11.1. Versiones fijadas para esta entrega, no presentadas como las últimas disponibles. Android Studio crea local.properties con la ruta de tu SDK.

```bash
./gradlew assembleDebug testDebugUnitTest lintDebug
./gradlew connectedDebugAndroidTest
```

Windows: `gradlew.bat`. El segundo comando requiere dispositivo o emulador. Salida del primero: `app/build/outputs/apk/debug/app-debug.apk`. La primera compilación necesita Internet. El APK debug está firmado automáticamente con una clave de desarrollo local; para distribución definitiva crea y conserva tu propia clave de release.

## Código

Data.kt: entidades y DAO Room, preferencias DataStore. ReaderLogic.kt: utilidades independientes de Android. PdfEngine.kt: PdfRenderer del sistema, PDFBox y límites de recursos. Translator.kt: modelos ML Kit, fragmentación y caché SHA-256. ReaderViewModel.kt: estado MVVM y coordinación de corrutinas. MainActivity.kt: seis pantallas Compose Material 3 y arte geométrico original.

## Privacidad

Los documentos no se suben a un servidor de traducción. ML Kit puede descargar modelos y enviar métricas técnicas de uso/rendimiento. El proveedor de archivos elegido puede usar Internet. La biblioteca y las traducciones se guardan en almacenamiento privado; backup Android desactivado. La extracción genera una copia temporal que se elimina al terminar; un cierre abrupto puede dejarla en caché. Borrar datos locales no borra tus PDF originales ni el modelo descargado; este último tiene su propio control de borrado.

Google Translate: https://cloud.google.com/translate . Condiciones y licencias en THIRD_PARTY_NOTICES.md.

## Lectura adaptable y traducción extensa (actualización pendiente de compilación)

En El Grimorio, «Lectura adaptable» presenta el texto extraído en párrafos de ancho móvil; «Español» muestra las páginas ya traducidas. Los controles A−/A+, Interlínea y Márgenes se guardan localmente. Para consultar imágenes, tablas o páginas sin texto, vuelve al PDF original. Allí puedes alternar entre ancho y página completa, ampliar con dos dedos y usar doble toque.

«Traducir página», «Traducir capítulo / rango» y «Traducir documento» procesan el texto extraíble con ML Kit. El modelo inglés y español debe descargarse desde Ajustes con Wi-Fi. El progreso indica las páginas terminadas; «Interrumpir» conserva páginas completadas y repetir la operación utiliza la caché. Una página escaneada sin OCR queda indicada como sin texto. El PDF original nunca se modifica.

Esta revisión de fuentes no pudo compilarse en el entorno de edición debido a la ausencia de SDK/Gradle y al bloqueo de red. Consulta `ABYSSAL_READER_CHANGELOG.md`; no instales el APK anterior esperando estas funciones.

### Compilación alternativa con GitHub Actions

El proyecto incluye `.github/workflows/android-debug.yml` y una copia independiente `ABYSSAL_READER_GITHUB_ACTIONS.yml`. Si dispones de un repositorio privado autorizado, sube **el contenido de la carpeta `AbyssalReader` a la raíz** de ese repositorio. En Actions inicia manualmente «ABYSSAL READER Android debug». Descarga el artefacto `ABYSSAL_READER_FINAL` cuando el trabajo termine correctamente; contendrá `app-debug.apk`. Si falla, descarga `abyssal-build-log`, revisa `build.log`, corrige el código y vuelve a ejecutarlo. Este workflow todavía no se ha ejecutado en esta sesión.
