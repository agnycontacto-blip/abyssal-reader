# Dependencias, licencias y fuentes

Las versiones se mantienen respecto al avance anterior. Se seleccionó un conjunto estable, no la última versión de cada componente. No se han elegido motores AGPL ni servicios de pago.

| Componente | Versión | Licencia / términos |
|---|---|---|
| AGP / Gradle | 8.9.2 / 8.11.1 | Apache 2.0 |
| Kotlin / Compose compiler | 2.1.20 | Apache 2.0 |
| Compose BOM | 2025.04.01 | AndroidX Apache 2.0 |
| Activity Compose | 1.10.1 | Apache 2.0 |
| Lifecycle | 2.8.7 | Apache 2.0 |
| Room | 2.7.1 | Apache 2.0 |
| DataStore | 1.1.4 | Apache 2.0 |
| Coroutines Play Services | 1.10.1 | Apache 2.0 |
| PDFBox Android | 2.0.27.0 | Apache 2.0; conservar avisos del port y de Apache |
| ML Kit Translation | 17.0.3 | Condiciones ML Kit y Google APIs, atribución Google Translate |
| JUnit (pruebas) | 4.13.2 | EPL 1.0 |

PdfRenderer es parte del sistema Android. La licencia de los ejemplos de ML Kit no debe confundirse con la del SDK propietario. La app atribuye Google Translate junto a los resultados y en las acciones. Los avisos META-INF de dependencias se fusionan dentro del APK. Antes de distribuir comercialmente: revisar dependencias transitivas, target SDK requerido por la tienda, privacidad, firma de release y composición exacta de la atribución oficial. No se certifica aquí cumplimiento comercial completo.

Fuentes oficiales consultadas en el desarrollo anterior:

- https://developer.android.com/build/releases/agp-8-9-0-release-notes
- https://github.com/TomRoush/PdfBox-Android
- https://android.googlesource.com/platform/frameworks/support/+/androidx-main/LICENSE.txt
- https://developers.google.com/ml-kit/language/translation/android
- https://developers.google.com/ml-kit/terms
- https://developers.google.com/ml-kit/language/translation/translation-terms
- https://cloud.google.com/translate/attribution

El logotipo Google procede sin alteraciones de https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_74x24dp.png y aparece con texto de atribución. Es una marca de Google, no de AGNY. El ZIP de badges oficiales no pudo descargarse en el avance previo; validar la franja contra la guía vigente antes de publicar. Los tentáculos y motivos de la app son dibujos geométricos originales por código.
