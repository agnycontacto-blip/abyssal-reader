package com.agny.abyssal
import org.junit.Assert.*
import org.junit.Test
class ReaderLogicTest {
 @Test fun pageBounds(){assertEquals(0,pageIndex("1",12));assertEquals(11,pageIndex("12",12));assertNull(pageIndex("0",12));assertNull(pageIndex("13",12));assertNull(pageIndex("abc",12));assertNull(pageIndex("999999999999",12))}
 @Test fun chunksPreserveEveryCharacter(){val text=("The forbidden library holds ancient books.\n").repeat(200);val chunks=translationChunks(text);assertEquals(text,chunks.joinToString(""));assertTrue(chunks.all{it.length<=1800});assertTrue(chunks.size>1)}
 @Test fun longWordDoesNotLoop(){val text="x".repeat(9001);assertEquals(text,translationChunks(text).joinToString(""));assertEquals(6,translationChunks(text).size)}
 @Test fun emptyInputHasNoChunks(){assertTrue(translationChunks("").isEmpty())}
 @Test fun unicodeSurrogatesStayTogether(){val text="a".repeat(1799)+"😀"+"b".repeat(2000);val chunks=translationChunks(text);assertEquals(text,chunks.joinToString(""));assertFalse(chunks.any{it.last().isHighSurrogate()})}
 @Test fun fullDocumentPartsPreserveParagraphs(){for(pages in listOf(1,20,120)){val text=(1..pages).joinToString("\n\n"){"CHAPTER $it\n"+("A sentence of the forbidden library. ".repeat(200))+"\nClosing line $it."};val parts=translationParts(text);assertEquals(text,parts.joinToString(""));assertTrue(parts.all{it.length<=1800});assertEquals(pages-1,Regex("\\n\\nCHAPTER").findAll(parts.joinToString("")).count())}}
 @Test fun unicodeAndBlankLinesSurvive(){val input="Title\r\n\r\n😀\n"+"a".repeat(5000)+"\n";assertEquals(input,translationParts(input).joinToString(""))}
}
