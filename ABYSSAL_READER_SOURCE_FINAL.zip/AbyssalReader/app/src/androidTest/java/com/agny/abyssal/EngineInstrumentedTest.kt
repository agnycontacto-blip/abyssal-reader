package com.agny.abyssal
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import android.content.Context
import androidx.room.Room
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import org.junit.Assert.*
import org.junit.Test
import java.io.File
class EngineInstrumentedTest {
 private val context=ApplicationProvider.getApplicationContext<Context>()
 @Test fun renderAndExtractDigitalPdf()=runBlocking{
  val file=File(context.cacheDir,"digital-fixture.pdf")
  val doc=PdfDocument();try{repeat(2){index->val page=doc.startPage(PdfDocument.PageInfo.Builder(400,600,index+1).create());page.canvas.drawText("The ancient library is open.",30f,80f,Paint().apply{textSize=18f});doc.finishPage(page)};file.outputStream().use{doc.writeTo(it)}}finally{doc.close()}
  try{val engine=PdfEngine(context);val uri=Uri.fromFile(file).toString();assertEquals(2,engine.count(uri));val bitmap=engine.render(uri,1);assertTrue(bitmap.width*bitmap.height<=2_000_000);bitmap.recycle();assertTrue(engine.text(uri,0).contains("ancient library"))}finally{file.delete()}
 }
 @Test fun corruptPdfFailsClearly()=runBlocking{val file=File(context.cacheDir,"bad.pdf");file.writeText("not a PDF");try{assertTrue(runCatching{PdfEngine(context).count(Uri.fromFile(file).toString())}.isFailure)}finally{file.delete()}}
 @Test fun roomRetainsProgressBookmarksAndVocabulary()=runBlocking{
  val name="test-${System.nanoTime()}.db";var db=Room.databaseBuilder(context,LibraryDb::class.java,name).build()
  try{db.dao().put(Book("test-uri","Example",10));db.dao().progress("test-uri",4,123L);db.dao().mark(Mark("test-uri",4));db.dao().put(Entry("test-key","library","biblioteca","Example",4));db.dao().save("test-key");db.close();db=Room.databaseBuilder(context,LibraryDb::class.java,name).build();assertEquals(4,db.dao().book("test-uri")!!.page);assertEquals(4,db.dao().marks("test-uri").first().single().page);assertTrue(db.dao().cached("test-key")!!.saved)}finally{db.close();context.deleteDatabase(name)}
 }
}
