package com.agny.abyssal
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
class PortalInstrumentedTest {
 @get:Rule val compose=createAndroidComposeRule<MainActivity>()
 @Test fun opensLibraryAndSettings(){compose.onNodeWithText("Entrar a la biblioteca").performClick();compose.onNodeWithText("Biblioteca Prohibida").assertIsDisplayed();compose.onNodeWithText("Ajustes").performClick();compose.onNodeWithText("Configuración Arcana").assertIsDisplayed()}
}
