package com.agny.abyssal
fun pageIndex(input:String,count:Int):Int?=input.toIntOrNull()?.takeIf{it in 1..count}?.minus(1)
fun translationChunks(text:String,limit:Int=1800):List<String>{
 require(limit>=2)
 val result=mutableListOf<String>();var start=0
 while(start<text.length){
  var end=minOf(start+limit,text.length)
  if(end<text.length){val boundary=text.lastIndexOf(' ',end-1);if(boundary>start+limit/2)end=boundary+1}
  if(end<text.length&&text[end-1].isHighSurrogate()&&text[end].isLowSurrogate())end--
  result+=text.substring(start,end);start=end
 }
 return result
}
// Keep every UTF-16 code unit and every paragraph boundary in source order.
fun translationParts(text:String,limit:Int=1800):List<String> {
 val parts=mutableListOf<String>()
 val lines=Regex("(?<=\\n)").split(text)
 for(line in lines){
  if(line.isBlank()){parts+=line;continue}
  val trailing=line.takeLastWhile{it=='\n'||it=='\r'}
  val body=line.dropLast(trailing.length)
  parts+=translationChunks(body,limit)
  if(trailing.isNotEmpty())parts+=trailing
 }
 check(parts.joinToString("")==text)
 return parts
}
