package com.agny.abyssal
import android.os.Bundle
import android.app.Activity
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.*
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlin.math.*
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{AbyssalApp()}}}
private val Gold=Color(0xFFB49A65)
private val Parchment=Color(0xFFD8C9A7)
@Composable fun AbyssalApp(vm:ReaderViewModel=viewModel()){
 val light by vm.preferences.parchment.collectAsState(false);val large by vm.preferences.largeText.collectAsState(false)
 val screen by vm.screen.collectAsState();val busy by vm.busy.collectAsState();val message by vm.message.collectAsState()
 val colors=if(light)lightColorScheme(primary=Color(0xFF425B42),background=Parchment,surface=Color(0xFFE7DBC0),onSurface=Color(0xFF191B17))else darkColorScheme(primary=Gold,background=Color(0xFF090B0D),surface=Color(0xFF14201E),onSurface=Parchment,secondary=Color(0xFF97B9AC))
 MaterialTheme(colorScheme=colors,typography=Typography(bodyLarge=androidx.compose.ui.text.TextStyle(fontFamily=FontFamily.Serif,fontSize=if(large)21.sp else 17.sp,lineHeight=if(large)31.sp else 26.sp))){
  Surface(Modifier.fillMaxSize()){
   Column(Modifier.fillMaxSize().safeDrawingPadding()){
    if(busy)LinearProgressIndicator(Modifier.fillMaxWidth())
    Box(Modifier.weight(1f)){when(screen){"portal"->Portal(vm);"library"->Library(vm);"reader"->Reader(vm);"oracle"->Oracle(vm);"archive"->Archive(vm);"settings"->Settings(vm)}}
   }
   if(message!=null)AlertDialog(onDismissRequest={vm.message.value=null},title={Text("Mensaje del archivo")},text={Text(message!!)},confirmButton={TextButton(onClick={vm.message.value=null}){Text("Entendido")}})
  }
 }
 BackHandler(enabled=screen!="portal"&&screen!="library"){vm.screen.value=if(screen=="oracle"&&vm.active.value!=null)"reader" else "library"}
}
@Composable fun Heading(title:String,subtitle:String,back:(()->Unit)?=null){Column(Modifier.fillMaxWidth().padding(20.dp,12.dp)){
 if(back!=null)TextButton(onClick=back){Text("‹ Biblioteca")}
 Text(subtitle.uppercase(),style=MaterialTheme.typography.labelSmall,letterSpacing=3.sp,color=MaterialTheme.colorScheme.primary,maxLines=2)
 Text(title,fontFamily=FontFamily.Serif,style=MaterialTheme.typography.headlineMedium)
}}
@Composable fun Sigil(modifier:Modifier=Modifier){Canvas(modifier){
 val cx=size.width/2;val cy=size.height/2;val r=minOf(cx,cy)*.88f
 drawCircle(Gold.copy(alpha=.55f),r,style=Stroke(1.3f));drawCircle(Gold.copy(alpha=.3f),r*.91f,style=Stroke(1f))
 for(i in 0 until 48){val a=i*PI/24;drawLine(Gold,Offset(cx+cos(a).toFloat()*r,cy+sin(a).toFloat()*r),Offset(cx+cos(a).toFloat()*r*.97f,cy+sin(a).toFloat()*r*.97f),1f)}
 drawOval(Color(0xFF193B35),Offset(cx-r*.33f,cy-r*.55f),androidx.compose.ui.geometry.Size(r*.66f,r*.75f))
 for(i in 0..7){val x=cx+(i-3.5f)*r*.085f;val d=if(i<4)-1 else 1;val reach=r*(.35f+abs(i-3.5f)*.12f)
  val path=Path().apply{moveTo(x,cy);cubicTo(x+d*reach,cy+r*.7f,cx+d*reach*1.2f,cy-r*.18f,cx+d*reach,cy+r*.37f);cubicTo(cx+d*reach*.9f,cy+r*.65f,x+d*r*.2f,cy+r*.75f,x,cy+r*.18f)};drawPath(path,Gold,style=Stroke(r*.014f))}
 for(i in 0..14){val y=cy-r*.5f+i*r*.045f;val half=sqrt(maxOf(0f,1f-((y-(cy-r*.2f))/(r*.36f)).pow(2)))*r*.28f;drawLine(Gold.copy(alpha=.5f),Offset(cx-half,y),Offset(cx+half,y),1f)}
 drawLine(Parchment,Offset(cx-r*.2f,cy-r*.17f),Offset(cx-r*.06f,cy-r*.1f),3f);drawLine(Parchment,Offset(cx+r*.2f,cy-r*.17f),Offset(cx+r*.06f,cy-r*.1f),3f)
}}
@Composable fun Portal(vm:ReaderViewModel){
 val animate by vm.preferences.animation.collectAsState(true);var appeared by remember{mutableStateOf(false)}
 val alpha by animateFloatAsState(if(appeared)1f else 0f,tween(if(animate)900 else 0),label="portal")
 LaunchedEffect(Unit){appeared=true}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(30.dp).graphicsLayer{this.alpha=alpha},horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
  Text("A G N Y   •   D I G I T A L",color=Gold,style=MaterialTheme.typography.labelSmall)
  Sigil(Modifier.size(270.dp).padding(12.dp))
  Text("ABYSSAL\nREADER",fontFamily=FontFamily.Serif,fontSize=42.sp,lineHeight=44.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
  Text("THE FORBIDDEN LIBRARY",letterSpacing=3.sp,fontSize=10.sp,modifier=Modifier.padding(16.dp))
  Text("Cruza el umbral de otra lengua.",fontFamily=FontFamily.Serif);Spacer(Modifier.height(36.dp))
  Button(onClick={vm.screen.value="library"}){Text("Entrar a la biblioteca")}
 }
}
@Composable fun Library(vm:ReaderViewModel){
 val books by vm.books.collectAsState();var query by rememberSaveable{mutableStateOf("")};var favorites by rememberSaveable{mutableStateOf(false)}
 val importer=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let(vm::import)};val busy by vm.busy.collectAsState()
 Column{
  Heading("Biblioteca Prohibida","Volúmenes del abismo")
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){TextButton(onClick={vm.screen.value="archive"}){Text("Archivo")};TextButton(onClick={vm.manual()}){Text("Oráculo")};TextButton(onClick={vm.screen.value="settings"}){Text("Ajustes")}}
  OutlinedTextField(query,{query=it},label={Text("Buscar un volumen")},modifier=Modifier.fillMaxWidth().padding(horizontal=20.dp),singleLine=true)
  Row(Modifier.padding(horizontal=20.dp),verticalAlignment=Alignment.CenterVertically){FilterChip(favorites,{favorites=!favorites},label={Text("Favoritos")});Spacer(Modifier.weight(1f));Button(enabled=!busy,onClick={importer.launch(arrayOf("application/pdf"))}){Text("+ Importar PDF")}}
  Text("RECIENTES · ${books.size} VOLÚMENES",modifier=Modifier.padding(20.dp,8.dp),style=MaterialTheme.typography.labelSmall)
  LazyColumn(contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   if(books.isEmpty())item{Text("Tu biblioteca espera su primer grimorio. Importa un PDF desde tu dispositivo.")}
   items(books.filter{(!favorites||it.favorite)&&it.title.contains(query,true)},key={it.uri}){book->Card(Modifier.fillMaxWidth()){
    Row(Modifier.fillMaxWidth().clickable{vm.open(book)}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Thumbnail(vm,book);Column(Modifier.weight(1f).padding(start=14.dp)){
     Text(book.title,fontFamily=FontFamily.Serif,maxLines=2);Text("${book.pages} páginas · ${(book.page+1)*100/book.pages} %",style=MaterialTheme.typography.labelSmall)
     LinearProgressIndicator(progress={(book.page+1).toFloat()/book.pages},modifier=Modifier.fillMaxWidth().padding(top=12.dp))}}
    Row{TextButton(onClick={vm.work{vm.dao.favorite(book.uri)}}){Text(if(book.favorite)"★ Favorito" else "☆ Favorito")};TextButton(onClick={vm.remove(book)}){Text("Quitar")}}
   }}
  }
 }
}
@Composable fun Thumbnail(vm:ReaderViewModel,book:Book){
 val image by produceState<android.graphics.Bitmap?>(null,book.uri){value=try{vm.pdf.render(book.uri,0,160)}catch(e:kotlinx.coroutines.CancellationException){throw e}catch(e:Exception){null}}
 Box(Modifier.size(62.dp,88.dp).background(Color(0xFF193B35)),contentAlignment=Alignment.Center){image?.let{Image(it.asImageBitmap(),"Portada de ${book.title}",Modifier.fillMaxSize())}?:Text("PDF",color=Gold)}
}
@Composable fun Reader(vm:ReaderViewModel){
 val book by vm.active.collectAsState();val b=book?:return;val list=rememberLazyListState(initialFirstVisibleItemIndex=b.page);val scope=rememberCoroutineScope()
 val marks by remember(b.uri){vm.dao.marks(b.uri)}.collectAsState(emptyList())
 var full by rememberSaveable{mutableStateOf(false)};var jump by rememberSaveable{mutableStateOf("")};var showMarks by remember{mutableStateOf(false)};var showRange by remember{mutableStateOf(false)};var rangeStart by remember{mutableStateOf("")};var rangeEnd by remember{mutableStateOf("")};val context=LocalContext.current
 var reflow by rememberSaveable(b.uri){mutableStateOf(false)};var spanish by rememberSaveable(b.uri){mutableStateOf(false)};var fitPage by rememberSaveable(b.uri){mutableStateOf(false)}
 val translationProgress by vm.translationProgress.collectAsState()
 val translatedPages by vm.translatedPages.collectAsState()
 val fontSize by vm.preferences.readerSize.collectAsState(18);val spacing by vm.preferences.readerSpacing.collectAsState(145);val margin by vm.preferences.readerMargin.collectAsState(20)
 DisposableEffect(full){val activity=context as Activity;val controller=WindowCompat.getInsetsController(activity.window,activity.window.decorView);controller.systemBarsBehavior=WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
  if(full)controller.hide(WindowInsetsCompat.Type.systemBars())else controller.show(WindowInsetsCompat.Type.systemBars());onDispose{controller.show(WindowInsetsCompat.Type.systemBars())}}
 LaunchedEffect(b.uri,list){snapshotFlow{list.firstVisibleItemIndex}.distinctUntilChanged().collect{vm.progress(it)}}
 Column{
  if(!full){Heading("El Grimorio",b.title){vm.screen.value="library"};Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),verticalAlignment=Alignment.CenterVertically){
   OutlinedTextField(jump,{jump=it},placeholder={Text("Página")},singleLine=true,modifier=Modifier.width(100.dp))
   TextButton(onClick={val page=pageIndex(jump,b.pages);if(page!=null)scope.launch{list.scrollToItem(page)}else vm.message.value="Escribe una página entre 1 y ${b.pages}."}){Text("Ir")}
   TextButton(onClick={vm.work{if(marks.any{it.page==b.page})vm.dao.unmark(b.uri,b.page)else vm.dao.mark(Mark(b.uri,b.page))}}){Text(if(marks.any{it.page==b.page})"★ Marcada" else "☆ Marcar")}
   TextButton(onClick={showMarks=true}){Text("Marcadores")};TextButton(onClick={vm.extract(b.page)}){Text("Texto / Traducir")}
  }}
  Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),verticalAlignment=Alignment.CenterVertically){
   FilterChip(reflow,{reflow=it},label={Text("Lectura adaptable")},modifier=Modifier.padding(horizontal=8.dp))
   if(reflow){FilterChip(spanish,{spanish=it},label={Text(if(spanish)"Español" else "English")},modifier=Modifier.padding(end=8.dp))
    TextButton(onClick={vm.work{vm.preferences.setInt("readerSize",(fontSize-2).coerceAtLeast(12))}}){Text("A−")}
    Text("$fontSize sp");TextButton(onClick={vm.work{vm.preferences.setInt("readerSize",(fontSize+2).coerceAtMost(36))}}){Text("A+")}
    TextButton(onClick={vm.work{vm.preferences.setInt("readerSpacing",if(spacing>=180)120 else spacing+15)}}){Text("Interlínea")}
    TextButton(onClick={vm.work{vm.preferences.setInt("readerMargin",if(margin>=40)8 else margin+8)}}){Text("Márgenes")}
   }else TextButton(onClick={fitPage=!fitPage}){Text(if(fitPage)"Ajustar ancho" else "Página completa")}
   TextButton(onClick={vm.translateDocument(b.page,b.page)}){Text("Traducir página")}
   TextButton(onClick={rangeStart="${b.page+1}";rangeEnd="${b.page+1}";showRange=true}){Text("Traducir capítulo / rango")}
   TextButton(onClick={vm.translateDocument()}){Text("Traducir documento")}
   if(translationProgress!=null)TextButton(onClick={vm.stopTranslation()}){Text("Interrumpir")}
  }
  if(translationProgress!=null)Text(translationProgress!!,Modifier.padding(horizontal=16.dp),style=MaterialTheme.typography.labelMedium)
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("${b.page+1} / ${b.pages}",Modifier.padding(horizontal=16.dp),style=MaterialTheme.typography.labelMedium);TextButton(onClick={full=!full}){Text(if(full)"Mostrar controles" else "Pantalla completa")}}
  LazyColumn(state=list,modifier=Modifier.weight(1f).fillMaxWidth().background(if(reflow)MaterialTheme.colorScheme.background else Color(0xFF303333)),verticalArrangement=Arrangement.spacedBy(10.dp)){items(b.pages,key={it}){index->if(reflow)ReflowPage(vm,b,index,spanish,fontSize,spacing,margin,translatedPages.contains(index)){reflow=false}else PdfPage(vm,b.uri,index,fitPage)}}
 }
 if(showMarks)AlertDialog(onDismissRequest={showMarks=false},title={Text("Marcadores")},text={LazyColumn{if(marks.isEmpty())item{Text("Aún no hay marcadores.")};items(marks){mark->TextButton(onClick={scope.launch{list.scrollToItem(mark.page)};showMarks=false}){Text("Página ${mark.page+1}")}}}},confirmButton={TextButton(onClick={showMarks=false}){Text("Cerrar")}})
 if(showRange)AlertDialog(onDismissRequest={showRange=false},title={Text("Páginas del capítulo")},text={Column{Text("Indica la primera y la última página del tramo identificado en el PDF.");OutlinedTextField(rangeStart,{rangeStart=it},label={Text("Desde")});OutlinedTextField(rangeEnd,{rangeEnd=it},label={Text("Hasta")})}},confirmButton={TextButton(onClick={val first=pageIndex(rangeStart,b.pages);val last=pageIndex(rangeEnd,b.pages);if(first!=null&&last!=null&&first<=last){vm.translateDocument(first,last);showRange=false}else vm.message.value="Escribe un rango válido entre 1 y ${b.pages}."}){Text("Traducir tramo")}},dismissButton={TextButton(onClick={showRange=false}){Text("Cancelar")}})
}
@Composable fun ReflowPage(vm:ReaderViewModel,book:Book,page:Int,spanish:Boolean,fontSize:Int,spacing:Int,margin:Int,translated:Boolean,showPdf:()->Unit){
 val content by produceState("Cargando texto…",book.uri,page,spanish,translated){value=try{vm.reflowPage(book,page,spanish)}catch(e:kotlinx.coroutines.CancellationException){throw e}catch(e:Exception){"No se pudo extraer la página ${page+1}: ${e.message}"}}
 Column(Modifier.fillMaxWidth().padding(horizontal=margin.dp,vertical=20.dp)){
  Text("✦  PÁGINA ${page+1}",color=MaterialTheme.colorScheme.primary,style=MaterialTheme.typography.labelMedium)
  SelectionContainer{Text(content,fontFamily=FontFamily.Serif,fontSize=fontSize.sp,lineHeight=(fontSize*spacing/100f).sp,modifier=Modifier.fillMaxWidth().padding(top=12.dp))}
  if(content.startsWith("Esta página no contiene")||content.startsWith("No se pudo extraer"))TextButton(onClick=showPdf){Text("Consultar PDF original")}
 }
}
@Composable fun PdfPage(vm:ReaderViewModel,uri:String,page:Int,fitPage:Boolean){
 var bitmap by remember(uri,page){mutableStateOf<android.graphics.Bitmap?>(null)};var error by remember(uri,page){mutableStateOf<String?>(null)}
 var scale by rememberSaveable(uri,page){mutableFloatStateOf(1f)};var x by rememberSaveable(uri,page){mutableFloatStateOf(0f)};var y by rememberSaveable(uri,page){mutableFloatStateOf(0f)};var pageSize by remember{mutableStateOf(IntSize.Zero)}
 LaunchedEffect(uri,page){try{bitmap=vm.pdf.render(uri,page)}catch(e:kotlinx.coroutines.CancellationException){throw e}catch(e:Exception){error="No se pudo abrir esta página. ${e.message?:""}"}}
 val ratio=bitmap?.let{it.width.toFloat()/it.height}?:.707f
 val transform=rememberTransformableState{zoom,pan,_->scale=(scale*zoom).coerceIn(1f,5f);val maxX=pageSize.width*(scale-1)/2;val maxY=pageSize.height*(scale-1)/2;x=(x+pan.x).coerceIn(-maxX,maxX);y=(y+pan.y).coerceIn(-maxY,maxY)}
 val config=LocalConfiguration.current
 val pageWidth=if(fitPage)minOf(config.screenWidthDp.toFloat(),(config.screenHeightDp-160).coerceAtLeast(250)*ratio).dp else config.screenWidthDp.dp
 Box(Modifier.fillMaxWidth(),contentAlignment=Alignment.Center){Box(Modifier.width(pageWidth).aspectRatio(ratio).onSizeChanged{pageSize=it}.clipToBounds().background(Color.White)
  .pointerInput(uri,page){detectTapGestures(onDoubleTap={scale=if(scale>1f)1f else 2.5f;x=0f;y=0f})}
  .transformable(state=transform,canPan={scale>1f}),contentAlignment=Alignment.Center){
  bitmap?.let{Image(it.asImageBitmap(),"Página ${page+1}",Modifier.fillMaxSize().graphicsLayer{scaleX=scale;scaleY=scale;translationX=x;translationY=y})}
  if(bitmap==null&&error==null)CircularProgressIndicator();error?.let{Text(it,color=Color.Black,modifier=Modifier.padding(16.dp))}
  if(scale>1f)TextButton(onClick={scale=1f;x=0f;y=0f},modifier=Modifier.align(Alignment.TopEnd).background(Color.Black.copy(alpha=.8f))){Text("Restablecer",color=Gold)}
 }}
}
@Composable fun Oracle(vm:ReaderViewModel){
 val source by vm.source.collectAsState();val result by vm.result.collectAsState();val ready by vm.modelReady.collectAsState();val busy by vm.busy.collectAsState()
 var field by remember{mutableStateOf(TextFieldValue(source))};LaunchedEffect(source){if(field.text!=source)field=TextFieldValue(source)};val clipboard=LocalClipboardManager.current
 Column(Modifier.verticalScroll(rememberScrollState())){
  Heading("Oráculo de las Lenguas","Inglés → Español"){vm.screen.value="library"}
  Text(if(ready)"● Modelo disponible sin conexión" else "○ Modelo pendiente de descarga",Modifier.padding(horizontal=20.dp),color=MaterialTheme.colorScheme.primary)
  Text("Mantén pulsado el texto y ajusta la selección. Traducir selección usa el fragmento resaltado; Traducir página usa todo el campo.",Modifier.padding(20.dp),style=MaterialTheme.typography.bodySmall)
  OutlinedTextField(field,{field=it;if(it.text!=source)vm.editSource(it.text)},label={Text("Original · inglés")},modifier=Modifier.fillMaxWidth().padding(horizontal=20.dp).heightIn(min=180.dp,max=360.dp))
  Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(12.dp)){
   Button(enabled=!busy&&!field.selection.collapsed,onClick={vm.translate(field.text.substring(field.selection.min,field.selection.max))}){Text("Traducir selección con Google")}
   TextButton(enabled=!busy&&source.isNotBlank(),onClick={vm.translate(source)}){Text("Traducir página con Google")}}
  if(!ready)TextButton(enabled=!busy,onClick={vm.download()},modifier=Modifier.padding(horizontal=16.dp)){Text("Descargar modelo por Wi-Fi")}
  result?.let{entry->Card(Modifier.fillMaxWidth().padding(20.dp)){Column(Modifier.padding(20.dp)){
   Text("INGLÉS",style=MaterialTheme.typography.labelSmall);SelectionContainer{Text(entry.original)};HorizontalDivider(Modifier.padding(vertical=18.dp))
   Text("ESPAÑOL",style=MaterialTheme.typography.labelSmall);SelectionContainer{Text(entry.translated)};Attribution();Text("Traducción automática; puede contener errores.",style=MaterialTheme.typography.labelSmall)
   Row{TextButton(onClick={clipboard.setText(AnnotatedString(entry.translated))}){Text("Copiar")};TextButton(onClick={vm.work{vm.dao.save(entry.key);vm.message.value="Guardado en Archivo de Conocimientos."}}){Text("Guardar")}}
  }}}
  TextButton(onClick={vm.screen.value="archive"}){Text("Consultar historial y vocabulario")};if(vm.active.value!=null)TextButton(onClick={vm.screen.value="reader"}){Text("Volver al PDF")}
 }
}
@Composable fun Attribution(){val links=LocalUriHandler.current
 Row(Modifier.padding(vertical=12.dp).background(Color.White).clickable{links.openUri("https://translate.google.com")}.padding(8.dp),verticalAlignment=Alignment.CenterVertically){Text("powered by ",color=Color(0xFF555555),fontSize=12.sp);Image(painterResource(R.drawable.google_logo),"Google",Modifier.size(74.dp,24.dp));Text(" Translate",color=Color(0xFF555555),fontSize=14.sp)}
}
@Composable fun Archive(vm:ReaderViewModel){
 val entries by vm.entries.collectAsState();var query by rememberSaveable{mutableStateOf("")};var onlySaved by rememberSaveable{mutableStateOf(true)};val clipboard=LocalClipboardManager.current
 Column{Heading("Archivo de Conocimientos","Palabras rescatadas"){vm.screen.value="library"}
  OutlinedTextField(query,{query=it},label={Text("Buscar término o documento")},modifier=Modifier.fillMaxWidth().padding(horizontal=20.dp))
  Row(Modifier.padding(horizontal=20.dp)){FilterChip(onlySaved,{onlySaved=true},label={Text("Vocabulario")});Spacer(Modifier.width(8.dp));FilterChip(!onlySaved,{onlySaved=false},label={Text("Historial")})}
  LazyColumn(contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   val filtered=entries.filter{(!onlySaved||it.saved)&&(it.original+it.translated+it.document).contains(query,true)}
   if(filtered.isEmpty())item{Text("Todavía no hay entradas para esta búsqueda.")}
   items(filtered,key={it.key}){entry->Card{Column(Modifier.fillMaxWidth().padding(16.dp)){
    Text("${entry.document} · página ${entry.page+1}",style=MaterialTheme.typography.labelSmall)
    SelectionContainer{Column{Text(entry.original);HorizontalDivider(Modifier.padding(vertical=10.dp));Text(entry.translated)}};Attribution()
    Row{TextButton(onClick={clipboard.setText(AnnotatedString(entry.translated))}){Text("Copiar")};if(!entry.saved)TextButton(onClick={vm.work{vm.dao.save(entry.key)}}){Text("Guardar")};TextButton(onClick={vm.work{vm.dao.delete(entry.key)}}){Text("Eliminar")}}
   }}}
  }
 }
}
@Composable fun Settings(vm:ReaderViewModel){
 val light by vm.preferences.parchment.collectAsState(false);val animate by vm.preferences.animation.collectAsState(true);val large by vm.preferences.largeText.collectAsState(false);val ready by vm.modelReady.collectAsState();val busy by vm.busy.collectAsState();var confirm by remember{mutableStateOf(false)}
 Column(Modifier.verticalScroll(rememberScrollState())){Heading("Configuración Arcana","El orden del archivo"){vm.screen.value="library"}
  Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
   SettingSwitch("Tema pergamino",light){vm.work{vm.preferences.set("parchment",it)}};SettingSwitch("Animación del portal",animate){vm.work{vm.preferences.set("animation",it)}};SettingSwitch("Texto grande en el oráculo",large){vm.work{vm.preferences.set("largeText",it)}}
   HorizontalDivider();Text("Lenguas: inglés → español",style=MaterialTheme.typography.titleMedium)
   Text(if(ready)"Modelo español descargado." else "Descarga necesaria. Conéctate a Wi-Fi; la primera descarga puede tardar varios minutos.")
   Button(enabled=!busy,onClick={vm.download()}){Text("Descargar / verificar modelo")};OutlinedButton(enabled=ready&&!busy,onClick={vm.deleteModel()}){Text("Eliminar modelo español")}
   HorizontalDivider();Text("Privacidad",style=MaterialTheme.typography.titleMedium)
   Text("Los PDF se abren desde el proveedor que elijas y no se envían a un servidor de traducción. Los resultados se guardan en este dispositivo. ML Kit descarga modelos y puede enviar métricas técnicas de uso. El proveedor de archivos puede necesitar conexión. Las copias de seguridad Android están desactivadas.")
   OutlinedButton(onClick={vm.work{vm.dao.clearCache()}}){Text("Borrar historial no guardado")};OutlinedButton(onClick={confirm=true}){Text("Borrar biblioteca y traducciones")}
   Text("Las traducciones automáticas de Google se ofrecen sin garantías de exactitud, fiabilidad, comerciabilidad, idoneidad ni ausencia de infracción. Consulta el original cuando la precisión sea esencial.",style=MaterialTheme.typography.bodySmall)
   Text("ABYSSAL READER · 0.1.0\nArte geométrico original · AGNY\nPDFBox Android / AndroidX: Apache 2.0.\nML Kit: condiciones de Google. Consulta THIRD_PARTY_NOTICES.md en el proyecto.",style=MaterialTheme.typography.bodySmall)
  }
 }
 if(confirm)AlertDialog(onDismissRequest={confirm=false},title={Text("¿Vaciar el archivo local?")},text={Text("Se borrarán biblioteca, marcadores, historial, vocabulario y preferencias. Tus PDF originales y el modelo descargado se conservarán.")},confirmButton={TextButton(onClick={confirm=false;vm.clearAll()}){Text("Borrar datos")}},dismissButton={TextButton(onClick={confirm=false}){Text("Cancelar")}})
}
@Composable fun SettingSwitch(title:String,checked:Boolean,changed:(Boolean)->Unit){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(title,Modifier.weight(1f));Switch(checked,changed)}}
