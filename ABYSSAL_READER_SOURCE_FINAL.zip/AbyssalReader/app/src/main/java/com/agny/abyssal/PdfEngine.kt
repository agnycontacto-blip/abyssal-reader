package com.agny.abyssal
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
class PdfEngine(private val context:Context){
 private val mutex=Mutex()
 private val extractionMutex=Mutex()
 init{PDFBoxResourceLoader.init(context)}
 private fun descriptor(uri:String)=context.contentResolver.openFileDescriptor(Uri.parse(uri),"r")?:error("No se puede acceder al documento. Impórtalo de nuevo.")
 suspend fun count(uri:String):Int=withContext(Dispatchers.IO){mutex.withLock{descriptor(uri).use{PdfRenderer(it).use{pdf->pdf.pageCount}}}}
 suspend fun render(uri:String,index:Int,width:Int=1100):Bitmap=withContext(Dispatchers.IO){mutex.withLock{
  descriptor(uri).use{fd->PdfRenderer(fd).use{pdf->pdf.openPage(index).use{page->
   val ratio=page.height.toDouble()/page.width
   val w=minOf(width,kotlin.math.sqrt(2_000_000.0/ratio).toInt()).coerceAtLeast(1)
   val h=(w*ratio).toInt().coerceAtLeast(1)
   Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888).also{it.eraseColor(Color.WHITE);page.render(it,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)}
  }}}
 }}
 suspend fun text(uri:String,page:Int):String=withContext(Dispatchers.IO){extractionMutex.withLock{
  val temp=File.createTempFile("extract-",".pdf",context.cacheDir)
  try{
   context.contentResolver.openInputStream(Uri.parse(uri))!!.use{input->temp.outputStream().use{output->
    val buffer=ByteArray(65536);var total=0L
    while(true){val n=input.read(buffer);if(n<0)break;total+=n;require(total<=300L*1024*1024){"Extracción limitada a PDF de 300 MB; puedes seguir leyendo."};output.write(buffer,0,n)}
   }}
   PDDocument.load(temp,MemoryUsageSetting.setupTempFileOnly()).use{doc->
    require(doc.currentAccessPermission.canExtractContent()){"El documento no permite extraer texto."}
    PDFTextStripper().apply{startPage=page+1;endPage=page+1;sortByPosition=true}.getText(doc).trim()
   }
  }finally{temp.delete()}
 }}
 suspend fun eachText(uri:String,first:Int,last:Int,consume:suspend(Int,String)->Unit)=withContext(Dispatchers.IO){
  val temp=File.createTempFile("extract-",".pdf",context.cacheDir)
  try{
   context.contentResolver.openInputStream(Uri.parse(uri))!!.use{input->temp.outputStream().use{output->
    val buffer=ByteArray(65536);var total=0L
    while(true){coroutineContext.ensureActive();val n=input.read(buffer);if(n<0)break;total+=n;require(total<=300L*1024*1024){"Extracción limitada a PDF de 300 MB."};output.write(buffer,0,n)}
   }}
   PDDocument.load(temp,MemoryUsageSetting.setupTempFileOnly()).use{doc->
    require(doc.currentAccessPermission.canExtractContent()){"El documento no permite extraer texto."}
    require(first in 0 until doc.numberOfPages&&last in first until doc.numberOfPages)
    val stripper=PDFTextStripper().apply{sortByPosition=true}
    for(index in first..last){coroutineContext.ensureActive();stripper.startPage=index+1;stripper.endPage=index+1;consume(index,stripper.getText(doc).trim())}
   }
  }finally{temp.delete()}
 }
}
