package com.agny.abyssal
import android.content.Context
import androidx.room.*
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
@Entity(tableName="books")
data class Book(@PrimaryKey val uri:String,val title:String,val pages:Int,val page:Int=0,val favorite:Boolean=false,val opened:Long=System.currentTimeMillis())
@Entity(tableName="marks",primaryKeys=["uri","page"])
data class Mark(val uri:String,val page:Int)
@Entity(tableName="translations")
data class Entry(@PrimaryKey val key:String,val original:String,val translated:String,val document:String,val page:Int,val saved:Boolean=false,val time:Long=System.currentTimeMillis())
@Dao interface LibraryDao {
 @Query("SELECT * FROM books ORDER BY opened DESC") fun books():Flow<List<Book>>
 @Query("SELECT * FROM books WHERE uri=:uri") suspend fun book(uri:String):Book?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(book:Book)
 @Query("UPDATE books SET page=:page, opened=:time WHERE uri=:uri") suspend fun progress(uri:String,page:Int,time:Long)
 @Query("UPDATE books SET favorite=NOT favorite WHERE uri=:uri") suspend fun favorite(uri:String)
 @Query("DELETE FROM books WHERE uri=:uri") suspend fun removeBook(uri:String)
 @Query("SELECT * FROM marks WHERE uri=:uri ORDER BY page") fun marks(uri:String):Flow<List<Mark>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun mark(mark:Mark)
 @Query("DELETE FROM marks WHERE uri=:uri AND page=:page") suspend fun unmark(uri:String,page:Int)
 @Query("DELETE FROM marks WHERE uri=:uri") suspend fun removeMarks(uri:String)
 @Query("SELECT * FROM translations WHERE saved=1 OR `key` IN (SELECT `key` FROM translations ORDER BY time DESC LIMIT 500) ORDER BY time DESC") fun entries():Flow<List<Entry>>
 @Query("SELECT * FROM translations WHERE `key`=:key") suspend fun cached(key:String):Entry?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(entry:Entry)
 @Query("UPDATE translations SET saved=1 WHERE `key`=:key") suspend fun save(key:String)
 @Query("DELETE FROM translations WHERE `key`=:key") suspend fun delete(key:String)
 @Query("DELETE FROM translations WHERE saved=0") suspend fun clearCache()
 @Query("DELETE FROM translations") suspend fun clearEntries()
 @Query("DELETE FROM marks") suspend fun clearMarks()
 @Query("DELETE FROM books") suspend fun clearBooks()
}
@Database(entities=[Book::class,Mark::class,Entry::class],version=1,exportSchema=false)
abstract class LibraryDb:RoomDatabase(){abstract fun dao():LibraryDao}
val Context.preferences by preferencesDataStore("arcana")
class Preferences(private val context:Context){
 val parchment=context.preferences.data.map{it[booleanPreferencesKey("parchment")]?:false}
 val animation=context.preferences.data.map{it[booleanPreferencesKey("animation")]?:true}
 val largeText=context.preferences.data.map{it[booleanPreferencesKey("largeText")]?:false}
 val readerSize=context.preferences.data.map{it[intPreferencesKey("readerSize")]?:18}
 val readerSpacing=context.preferences.data.map{it[intPreferencesKey("readerSpacing")]?:145}
 val readerMargin=context.preferences.data.map{it[intPreferencesKey("readerMargin")]?:20}
 suspend fun set(key:String,value:Boolean){context.preferences.edit{it[booleanPreferencesKey(key)]=value}}
 suspend fun setInt(key:String,value:Int){context.preferences.edit{it[intPreferencesKey(key)]=value}}
 suspend fun reset(){context.preferences.edit{it.clear()}}
}
