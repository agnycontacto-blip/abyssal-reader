package com.agny.abyssal
import com.google.mlkit.nl.translate.*
import com.google.mlkit.common.model.*
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.security.MessageDigest
class LanguageRepository(private val dao:LibraryDao){
 private val mutex=Mutex()
 private val translator=Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.SPANISH).build())
 private val manager=RemoteModelManager.getInstance()
 private val spanish=TranslateRemoteModel.Builder(TranslateLanguage.SPANISH).build()
 private val english=TranslateRemoteModel.Builder(TranslateLanguage.ENGLISH).build()
 suspend fun ready()=manager.isModelDownloaded(spanish).await()&&manager.isModelDownloaded(english).await()
 suspend fun download()=mutex.withLock{translator.downloadModelIfNeeded(DownloadConditions.Builder().requireWifi().build()).await()}
 suspend fun deleteModel()=mutex.withLock{manager.deleteDownloadedModel(spanish).await()}
 suspend fun translate(text:String,document:String,page:Int,displayName:String=document):Entry=mutex.withLock{
  require(text.isNotBlank()){"Selecciona texto para traducir."}
  val hash=key(text,document,page)
  dao.cached(hash)?.let{return@withLock it}
  check(ready()){"Descarga primero el modelo español desde Configuración Arcana (Wi-Fi)."}
  val parts=translationParts(text)
  val output=StringBuilder()
  for(index in parts.indices){
    val part=parts[index]
    if(part.isBlank()){output.append(part);continue}
    val prefix=part.takeWhile{it.isWhitespace()};val suffix=part.takeLastWhile{it.isWhitespace()}
    val content=part.substring(prefix.length,part.length-suffix.length)
    if(content.isBlank()){output.append(part);continue}
    var translatedPart:String?=null
    for(attempt in 1..3){
     try{translatedPart=translator.translate(content).await();check(!translatedPart.isNullOrBlank()){"Respuesta vacía"};break}
     catch(e:CancellationException){throw e}
     catch(e:Exception){if(attempt==3)throw IllegalStateException("Fragmento ${index+1}/${parts.size} de la página ${page+1} falló tras 3 intentos: ${e.message}",e);delay(attempt*250L)}
    }
    check(!translatedPart.isNullOrBlank()){"Fragmento ${index+1}/${parts.size} de la página ${page+1} sin resultado."}
    output.append(prefix).append(translatedPart).append(suffix)
  }
  val translated=output.toString()
  Entry(hash,text,translated,displayName,page).also{dao.put(it)}
 }
 suspend fun cached(text:String,document:String,page:Int):Entry?=dao.cached(key(text,document,page))
 private fun key(text:String,document:String,page:Int)=MessageDigest.getInstance("SHA-256").digest(("en-es-v2\u0000$document\u0000$page\u0000$text").toByteArray()).joinToString(""){"%02x".format(it)}
 fun close(){translator.close()}
}
