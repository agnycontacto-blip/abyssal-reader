package com.agny.abyssal
import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import androidx.room.withTransaction
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
class ReaderViewModel(app:Application):AndroidViewModel(app){
 private val db=Room.databaseBuilder(app,LibraryDb::class.java,"forbidden-library.db").build()
 val dao=db.dao();val preferences=Preferences(app);val pdf=PdfEngine(app);val languages=LanguageRepository(dao)
 val books=dao.books().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 val entries=dao.entries().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 val active=MutableStateFlow<Book?>(null);val screen=MutableStateFlow("portal");val busy=MutableStateFlow(false)
 val message=MutableStateFlow<String?>(null);val source=MutableStateFlow("");val result=MutableStateFlow<Entry?>(null);val modelReady=MutableStateFlow(false)
 val translationProgress=MutableStateFlow<String?>(null)
 val translatedPages=MutableStateFlow<Set<Int>>(emptySet())
 private var translationJob:Job?=null
 private var originTitle="Texto manual";private var originPage=0
 init{work{modelReady.value=languages.ready()}}
 fun work(block:suspend()->Unit){viewModelScope.launch{try{block()}catch(e:CancellationException){throw e}catch(e:Exception){message.value=e.message?:"No se pudo completar la operación."}}}
 private fun task(block:suspend()->Unit){if(busy.value)return;busy.value=true;viewModelScope.launch{try{block()}catch(e:CancellationException){throw e}catch(e:Exception){message.value=e.message?:"No se pudo completar la operación."}finally{busy.value=false}}}
 fun import(uri:Uri)=task{
  withContext(Dispatchers.IO){
   val resolver=getApplication<Application>().contentResolver
   val title=resolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())it.getString(0)else null}?:"Grimorio.pdf"
   val pages=pdf.count(uri.toString());require(pages>0){"Este PDF no tiene páginas."}
   resolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)
   val old=dao.book(uri.toString())
   val book=old?.copy(title=title,pages=pages,page=old.page.coerceIn(0,pages-1),opened=System.currentTimeMillis())?:Book(uri.toString(),title,pages)
   dao.put(book);active.value=book;translatedPages.value=emptySet()
  };screen.value="reader"
 }
 fun open(book:Book){active.value=book;translatedPages.value=emptySet();screen.value="reader"}
 fun progress(page:Int){val b=active.value?:return;active.value=b.copy(page=page);work{dao.progress(b.uri,page,System.currentTimeMillis())}}
 fun extract(page:Int)=task{
  val b=active.value?:return@task;val text=pdf.text(b.uri,page)
  if(text.isBlank()){message.value="Página sin texto extraíble: puede ser un escaneo. OCR no incluido en esta versión.";return@task}
  source.value=text;result.value=null;originTitle=b.uri;originPage=page;screen.value="oracle"
 }
 fun translate(text:String)=task{result.value=languages.translate(text,originTitle,originPage,active.value?.title?:originTitle)}
 fun translateDocument(first:Int=0,last:Int?=null){
  val b=active.value?:return
  if(translationJob?.isActive==true)return
  val end=(last?:b.pages-1).coerceAtMost(b.pages-1)
  translationJob=viewModelScope.launch{
   var done=0;var blank=0;var current=first
   translationProgress.value="Preparando páginas ${first+1}–${end+1}…"
   try{
    pdf.eachText(b.uri,first,end){page,text->
     current=page
     if(text.isBlank())blank++ else languages.translate(text,b.uri,page,b.title)
     done++;translatedPages.value=translatedPages.value+page;translationProgress.value="${done}/${end-first+1} páginas procesadas · ${blank} sin texto"
    }
    translationProgress.value=null
    message.value="Traducción terminada: $done páginas procesadas; $blank sin texto extraíble. Las páginas sin texto requieren OCR."
   }catch(e:CancellationException){translationProgress.value=null;message.value="Traducción interrumpida. Las páginas terminadas están guardadas; puedes reanudar."}
   catch(e:Exception){translationProgress.value=null;message.value="Traducción incompleta en página ${current+1}: ${e.message}. Puedes reanudar; se reutilizan las páginas guardadas."}
  }
 }
 fun stopTranslation(){translationJob?.cancel()}
 suspend fun reflowPage(book:Book,page:Int,spanish:Boolean):String{
  val text=pdf.text(book.uri,page)
  if(text.isBlank())return "Esta página no contiene texto extraíble. Consúltala en el PDF original; OCR aún no está disponible."
  if(!spanish)return text
  return languages.cached(text,book.uri,page)?.translated?:"Traducción pendiente de esta página. Pulsa «Traducir documento» o «Traducir página»."
 }
 fun editSource(text:String){source.value=text;result.value=null}
 fun manual(){source.value="";result.value=null;originTitle="Texto manual";originPage=0;screen.value="oracle"}
 fun download()=task{languages.download();modelReady.value=languages.ready();message.value="Modelo disponible para traducir sin conexión."}
 fun deleteModel()=task{languages.deleteModel();modelReady.value=languages.ready()}
 fun remove(book:Book)=work{db.withTransaction{dao.removeMarks(book.uri);dao.removeBook(book.uri)};runCatching{getApplication<Application>().contentResolver.releasePersistableUriPermission(Uri.parse(book.uri),Intent.FLAG_GRANT_READ_URI_PERMISSION)}}
 fun clearAll()=task{
  translationJob?.cancelAndJoin()
  val uris=books.value.map{it.uri};db.withTransaction{dao.clearMarks();dao.clearBooks();dao.clearEntries()}
  uris.forEach{runCatching{getApplication<Application>().contentResolver.releasePersistableUriPermission(Uri.parse(it),Intent.FLAG_GRANT_READ_URI_PERMISSION)}}
  preferences.reset();active.value=null;source.value="";result.value=null;screen.value="library"
 }
 override fun onCleared(){languages.close();db.close()}
}
