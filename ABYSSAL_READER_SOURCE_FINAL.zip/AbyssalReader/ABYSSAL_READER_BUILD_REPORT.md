# ABYSSAL READER — Informe de compilación

Fecha: 26 de octubre de 2026. Estado: **fuente actualizada respaldada; compilación final pendiente**.

## Recuperación y estado

Se conservó la revisión `ABYSSAL_READER_SOURCE_UPDATED.zip` producida previamente (integridad ZIP correcta) y se respaldó antes de modificarla. El proyecto contiene `:app`, Kotlin 2.1.20, Android Gradle Plugin 8.9.2, Gradle Wrapper 8.11.1, JDK 17, compile/target SDK 35 y min SDK 26. XML y recursos conservados. No hay repositorio Git en la carpeta ni un repositorio ABYSSAL READER accesible en la conexión de GitHub. El workflow se entrega sin publicarlo ni ejecutarlo.

## Implementación presente en la fuente

- Traducción Google ML Kit inglés→español por páginas y fragmentos de hasta 1800 unidades UTF-16, en orden; los saltos de línea se conservan. Resultado de página en Room identificado por URI, número de página y huella del texto. Traducción de página, rango/chapter identificado manualmente o documento; progreso por página; cancelación; al reanudar, la caché evita volver a traducir páginas completadas. Un fragmento fallido se reintenta hasta tres veces, se informa con su índice y **no se guarda como página terminada**.
- Extracción secuencial de PDFBox con archivo temporal y límite de 300 MiB; páginas sin texto distinguibles de fallo del traductor. Escaneos sin OCR.
- Modo adaptable con texto extraído redibujado a ancho móvil, tamaño/interlineado/márgenes en DataStore, alternancia original/traducido y progreso por número de página en Room. En PDF original, imagen de página con pinch zoom, doble toque, ajuste de ancho/página completa y navegación vertical.
- No se introdujo motor de traducción nuevo ni se modificó el PDF original.

## Compilación y verificación

| Comprobación | Resultado |
|---|---|
| Integridad del ZIP de fuente final | Correcta (`unzip -t`). |
| XML y configuración estructural | Revisados; sin compilación Android de esta revisión. |
| Gradle de la revisión actual | No ejecutado: falta distribución Gradle, SDK Android y caché de dependencias en este entorno. El intento inmediatamente anterior terminó antes de compilar en `Network is unreachable`, registrado en `verification/update-build-attempt.log`. Repetirlo sin acceso a repositorios no cambiaría el resultado. |
| APK final actualizado | **No generado.** No se renombró el APK de la revisión anterior. |
| JUnit e instrumentadas de la revisión actual | Fuentes preparadas, **no ejecutadas**. El workflow compila tests instrumentados y ejecuta JVM tests; no ejecuta pruebas Android sin dispositivo. |
| PDF de prueba 1, 20, 120 páginas | `pdfinfo` confirmó 1/20/120; `pdftotext` encontró el párrafo final de cada página (1/20/120). Verifica las muestras, no la aplicación. |
| Traducción real, reflow, zoom y persistencia en Android | **No verificados en ejecución** en esta revisión; no hay dispositivo/emulador disponible. |

Los registros de compilación y pruebas previos dentro de `verification/` corresponden al APK **anterior**, que no contiene las correcciones. No deben confundirse con un resultado de esta revisión.

## Limitaciones y riesgos

La extracción plana de PDFBox puede alterar el orden de columnas, tablas y figuras; consulta siempre el PDF original. No hay OCR. La caché se guarda por página, no por fragmento: si se interrumpe dentro de una página, se procesa esa página de nuevo. Un resultado no vacío del motor no prueba que la traducción sea semánticamente completa; solo se controla que todos los segmentos extraídos fueron enviados, respondieron sin error y se concatenaron en orden. La lectura adaptable extrae una página visible a la vez y puede ser lenta con PDF grandes en proveedores remotos. El zoom exacto y la retención de posición dentro de una página requieren prueba en dispositivo.

## Ruta reproducible y entrega pendiente

En un repositorio privado, coloca el contenido de `AbyssalReader/` en la raíz y ejecuta manualmente `.github/workflows/android-debug.yml`. El workflow instala JDK 17, SDK 35/Build Tools 35.0.0, usa el wrapper, compila `:app:assembleDebug`, corre `:app:testDebugUnitTest`, compila `:app:assembleDebugAndroidTest`, verifica la firma del APK y publica APK/logs como artefactos. **No se ha ejecutado este workflow**, pues no hay repositorio asociado. Si compila correctamente, descarga `ABYSSAL_READER_FINAL` y renombra su `app-debug.apk` a `ABYSSAL_READER_FINAL.apk`; calcula y coteja su SHA-256 publicado en `abyssal-build-log`.

Localmente, con SDK y red: `./gradlew :app:assembleDebug :app:testDebugUnitTest :app:assembleDebugAndroidTest --stacktrace`. Luego `adb install -r app/build/outputs/apk/debug/app-debug.apk`. Instala y valida en Android con los PDF incluidos antes de calificar las funciones como verificadas.
