# ABYSSAL READER — The Forbidden Library

Informe final de compilación · 26 de octubre de 2026 · versión 0.1.0

## Resultado

**APK debug compilado, firmado y validado estructuralmente. Ejecución en Android pendiente.**

| Comprobación | Resultado y evidencia |
|---|---|
| Compilación de la app | BUILD SUCCESSFUL. Primera compilación: 4 min 30 s. |
| Recompilación mediante Gradle Wrapper | BUILD SUCCESSFUL con assembleDebug, testDebugUnitTest y assembleDebugAndroidTest; registro final: 19 s. |
| Archivo APK | Existe: ABYSSAL_READER_DEBUG.apk, 102,341,929 bytes. |
| Estructura | ZIP íntegro; contiene AndroidManifest.xml y classes.dex. |
| Firma | apksigner: Verifies, esquema v2, un firmante de desarrollo. |
| Identidad | com.agny.abyssal · versionCode 1 · versionName 0.1.0. |
| Compatibilidad declarada | minSdk 26 (Android 8.0), target/compile SDK 35. No equivale a una prueba en todos los dispositivos. |
| Pruebas unitarias JVM | 5 aprobadas, 0 fallos, 0 errores, 0 omitidas. XML incluido. |
| Pruebas instrumentadas | Código y APK de pruebas compilados; NO ejecutados. |
| Dispositivo/emulador | adb devices no mostró dispositivos. No había emulador operativo; /dev/kvm ausente. No se descargó ni inició un emulador para retrasar la entrega. |
| Traducción real en Android | Integrada y compilada; NO verificada en ejecución. No se descargaron modelos. |
| Android Lint | No ejecutado en esta entrega. |

## Funciones implementadas y compiladas

Se conservó el alcance existente: Kotlin, Compose Material 3, MVVM, Room y DataStore; seis pantallas con motivos abisales originales. Biblioteca con importación SAF, títulos, miniaturas, favoritos, búsqueda, progreso y marcadores. Renderizado PDF vertical, zoom multitáctil, salto de página, pantalla completa y extracción PDFBox. Traducción inglés-español mediante ML Kit, descarga/borrado del modelo español, caché SHA-256, copia, historial, vocabulario y comparación bilingüe. Temas abisal/pergamino y preferencias locales.

La selección funciona sobre una vista de texto extraído, no sobre las coordenadas gráficas del PDF. No hay traducciones simuladas. El PDF original se conserva.

## Qué se probó realmente

Las cinco pruebas JVM verificaron límites de números de página, división de textos largos sin perder caracteres, palabras largas, texto vacío y conservación de pares Unicode. Estos resultados NO verifican el renderizado, la traducción ML Kit, los gestos o la persistencia dentro de Android.

Las pruebas instrumentadas preparadas cubren PDF digital de ejemplo, extracción, archivo corrupto, persistencia Room tras reabrir y navegación portal → biblioteca → ajustes. Se confirmó su compilación, no su ejecución. No se generaron capturas ni se afirmó haber usado un teléfono físico.

## Correcciones de finalización

1. Se recuperó exclusivamente la copia íntegra guardada AbyssalReader-Recovered.zip, porque el mantenimiento eliminó el entorno temporal. Se restauraron SDK, JDK y Gradle ausentes; no se rediseñó la app.
2. Se acotó Google Maven a sus grupos de dependencias, evitando búsquedas innecesarias.
3. Se añadió el Compose BOM a androidTestImplementation: el primer intento de compilar las pruebas no resolvía la versión de ui-test-junit4.
4. Se sustituyó use sobre PdfDocument por try/finally con close en EngineInstrumentedTest, pues ese tipo no satisface el receptor requerido por use. Solo se modificó el código de prueba afectado.
5. Se reejecutaron las tareas hasta obtener BUILD SUCCESSFUL. Se incluyen los registros de ambos fallos corregidos y el resultado final.

## Instalación

Descarga ABYSSAL_READER_DEBUG.apk en un Android 8.0 o posterior. Ábrelo y, si Android lo solicita, autoriza a esa aplicación concreta a instalar aplicaciones. Es una compilación de desarrollo firmada con clave debug, no una versión de tienda. No necesita registro, suscripción ni clave API.

En Configuración Arcana, conectado a Wi-Fi, descarga el modelo español. Importa un PDF digital, abre Texto / Traducir, selecciona un fragmento o traduce la página. La primera descarga de modelo no está incluida en el APK y requiere conexión. El funcionamiento posterior sin conexión está implementado pero aún requiere prueba en un dispositivo.

## Pendiente antes de considerar validación funcional completa

Instalar y abrir el APK; probar SAF con PDF real, desplazamiento, zoom, cambio de página, extracción, rotación, marcadores y recuperación de progreso. Descargar el modelo, traducir una frase nueva, activar modo avión y traducir otra frase nueva para distinguir ejecución local de caché. Probar errores de red/modelo y PDF dañados. Ejecutar las pruebas instrumentadas y medir memoria en un teléfono de gama media. Revisar accesibilidad.

## Limitaciones y avisos

OCR no implementado: un escaneo sin capa textual se puede leer pero no traducir directamente. Extracción limitada a PDF de 300 MB. Documentos protegidos o con fuentes/columnas complejas pueden impedir o alterar extracción. El zoom amplía un bitmap limitado a aproximadamente dos millones de píxeles por página; no es renderizado por mosaicos. No se midió rendimiento en Android.

El compilador advierte sobre LocalClipboardManager obsoleto; no es un error de compilación. Algunas bibliotecas nativas conservaron sus símbolos de depuración, aumentando el tamaño del APK. Se mantuvo el código funcional existente.

ML Kit procesa texto localmente, pero puede descargar modelos y enviar métricas técnicas. Revisar THIRD_PARTY_NOTICES.md, atribución oficial, dependencias transitivas, requisitos de tienda y firma release antes de distribución comercial. La entrega no certifica cumplimiento comercial completo.

## Compilar y probar

JDK 17; Android SDK 35; Build Tools 35.0.0; Gradle Wrapper 8.11.1; AGP 8.9.2; Kotlin 2.1.20. Android Studio genera local.properties con la ruta de tu SDK.

```bash
./gradlew :app:assembleDebug --stacktrace
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebugAndroidTest
./gradlew :app:connectedDebugAndroidTest
```

El último comando necesita un dispositivo o emulador. Windows: gradlew.bat. Salida del APK: app/build/outputs/apk/debug/app-debug.apk. El ZIP incluye Gradle Wrapper, código, recursos, documentación y verification/ con los registros y el XML de resultados. Excluye cachés, build/, local.properties y claves privadas de firma.

## SHA-256

```
3595d3a07705dccd1a55a5b613e9969634740f4e0bcc79e44d5150ea062ecc07  ABYSSAL_READER_DEBUG.apk
```
