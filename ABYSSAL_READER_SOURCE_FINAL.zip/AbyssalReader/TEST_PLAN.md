# Pruebas de aceptación pendientes / reproducibles

No interpretar esta lista como resultados aprobados. El informe técnico contiene resultados reales.

Automatizadas JVM: límites de página, partición sin pérdida, palabras largas, texto vacío y pares Unicode. Instrumentación: renderizar/extraer PDF generado, rechazar PDF corrupto, cerrar/reabrir Room con progreso/marcadores/vocabulario y navegar portal → biblioteca → ajustes.

En teléfono: importar PDF local y de nube; navegar, ampliar/restablecer, marcar, cerrar/reabrir y rotar. Probar fuente de sistema 150 %, tema pergamino, archivo borrado, PDF protegido, columnas y escaneo sin texto.

Traducción real: sin modelo solicitar traducción; descargar por Wi-Fi; traducir una frase nueva. Activar modo avión y traducir OTRA frase nueva para demostrar ejecución local, no caché. Repetir la primera para caché. Guardar, copiar, buscar y eliminar. Borrar modelo e historial, reiniciar y solicitar texto nuevo. No comparar contra una traducción exacta fija: evaluar significado y errores.

Rendimiento: PDF de 500+ páginas en dispositivo con poca RAM, registrar Memory Profiler y fluidez. El límite de bitmap no sustituye mediciones.

OCR futuro: cuando no haya texto extraíble, renderizar solo la página y ejecutar ML Kit Text Recognition Latin. Identificarlo como texto OCR, permitir correcciones y probar columnas, inclinación y bajo contraste. No hay botones OCR simulados.
